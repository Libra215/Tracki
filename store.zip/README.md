# Rookie Store

```yml
   Rookie Store adalah salah satu Start Up Toko Online di indonesia yang 
berfokus kepada Toko Game/Top Up. 
Dengan berbagai macam metode pembayaran yang tersedia, juga opsi tanpa kartu kredit, 
registrasi ataupun log-in. dan tentunya Murah, Aman, dan 100% Terpercaya.

   Pada awalnya Rookie Store bernama LiShop yang bertujuan untuk pembelajaran dalam 
membangun website, Namun dengan seiring berjalannya waktu akhirnya 
dikembangkan menjadi sebuah website E-Commerce Game.
```
###### Preview dapat anda lihat di [shop.aliazhar.my.id](https://shop.aliazhar.my.id) or [www.aliazhar.my.id](https://www.aliazhar.my.id).
```css
   Project ini Open-Source, bagi kalian yang ingin berkontribusi 
di project ini dengan senang hati saya persilahkan.

   Project belom sepenuhnya selesai bahkan belom mencapai 30%, 
karena keterbatasan pengetahuan saya akan bahasa yang digunakan 
untuk Client-side, maupun Server-side.

   Namun, Seiring berjalannya Waktu dan bertambahnya pengetahuan saya, 
Project ini akan terus saya kembangkan.
```

```yaml
   Jika kalian ingin menggunakan project ini, dimohon untuk izin dulu dan 
mencatumkan credit ke repository ini, Thank You
```


### Saran & Masukan
###### Jika Anda ingin memiliki kritik maupun saran, silahkan kirim E-mail ke <a href="mailto:aliazhar0555@gmail.com">aliazhar0555@gmail.com</a>.
   
### Support

###### Kami menerima bantuan pengembangan project melalui [Saweria](https://saweria.co/aliazhar) Jika anda tertarik.
