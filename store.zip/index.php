

<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<link rel="icon" href="img/icon.png">
		<meta name="viewport" content="width=device-width, initial-scale=1.0">
		<title>Faris Store</title>
		<meta name="description" content="Rookie Store adalah salah satu Start Up Toko Online di indonesia yang berfokus kepada Voucher Game. Dengan berbagai macam metode pembayaran yang tersedia,<br> juga opsi tanpa kartu kredit, registrasi ataupun log-in. dan tentunya Murah, Aman, dan 100% Terpercaya.">
		<meta name="keywords" content="rookie store, voucher game, toko game,top up, top up diamond, top up ff">
		<meta name="author" content="aliazhar">

		<!-- OpenGraph -->
		<meta property="og:title" content="Rookie Store">
		<meta property="og:description" content="Rookie Store adalah salah satu Start Up Toko Online di indonesia yang berfokus kepada Voucher Game. Dengan berbagai macam metode pembayaran yang tersedia,<br> juga opsi tanpa kartu kredit, registrasi ataupun log-in. dan tentunya Murah, Aman, dan 100% Terpercaya.">
		<meta property="og:url" content="https://shop.aliazhar.my.id">
		<meta property="og:image" content="https://dev.aliazhar.my.id/img/card/pubg.jpg">
		<meta property="og:image:alt" content="Rookie Store">

		<!-- Twitter -->
		<meta name="twitter:card" content="summary_large_image">
		<meta name="twitter:site" content="@aliazhar-id">
		<meta name="twitter:creator" content="@aliazhar-id">
		<meta name="twitter:title" content="aliazhar">
		<meta name="twitter:description" content="Rookie Store adalah salah satu Start Up Toko Online di indonesia yang berfokus kepada Voucher Game. Dengan berbagai macam metode pembayaran yang tersedia,<br> juga opsi tanpa kartu kredit, registrasi ataupun log-in. dan tentunya Murah, Aman, dan 100% Terpercaya.">
		<meta name="twitter:image" content="https://dev.aliazhar.my.id/img/card/pubg.jpg">
		<meta name="twitter:image:alt" content="aliazhar twitter">

		<!-- style css -->
		<link rel="stylesheet" href="css/reset.css">
		<link rel="stylesheet" href="css/animation.css">
		<link rel="stylesheet" href="css/style.css">
		<link rel="stylesheet" href="css/responsive.css">
	</head>
	<body>
		<!-- Start Particles -->
		<div id="particles-js"></div>
		<!-- End Particles -->

		<!-- Start Modal  -->
		<div class="modal">
			<div class="modal-content">
				<div class="modal-header">
					<h2>Faris Store</h2>
				</div>
				<div class="modal-body">
					<p>Saat ini masih dalam tahap alpha, Jika anda ingin order/membeli bisa langsung menghubungi kontak yang tercantum di bagian paling bawah halaman ini.</p>
				</div>
				<div class="modal-footer">
					<button id="modal-close-btn">Cancel</button>
					<button id="modal-ok-btn">OK</button>
				</div>
			</div>
		</div>
		<!-- End Modal -->

		<!-- Start Header -->
	<header>
		<div class="header-container">
			<div class="header-logo"><span>Faris</span> <span>Store</span></div>
			<div class="header-signin-button">Sign In | Sign Up</div>
			<div class="hamburger">
				<span></span><span></span><span></span>
			</div>
		</div>
	</header>
	<!-- End Header -->

	<!-- Start Form -->
	<form>
		<div class="form-container">
			<section>
				<div class="form-title">Faris Account</div>
			</section>
			<section>
				<div class="btncloseform">×</div>
			</section>
			<section>
				<label for="email">Email</label>
				<input type="email" name="email" placeholder="Your Email">
				<label for="password">Password</label>
				<input type="password" name="password" placeholder="Your Password">
				<button type="reset">Login</button>
			</section>
		</div>
	</form>
	<div class="overlay"></div>
	<!-- End Form -->

	<!-- Start Main/Card -->
	<main>
		<marquee behavior="scroll" scrollamount="6">Faris Store Saat ini masih dalam tahap perkembangan, Jika anda ingin order/membeli bisa langsung menghubungi kontak yang tercantum di bagian paling bawah halaman ini.</marquee>
		<div class="card">
			<div class="card-sizer">
				<img src="img/card/freefire.jpg" alt="Free Free" width="180px" height="180px">
				<div class="card-title">Free Fire</div>
			</div>
		</div>
		<div class="card">
			<div class="card-sizer">
				<img src="img/card/pubg.jpg" alt="PUBG" width="180px" height="180px">
				<div class="card-title">PUBG</div>
			</div>
		</div>
		<div class="card">
			<div class="card-sizer">
				<img src="img/card/mobilelegends.png" alt="Mobile Legends" width="180px" height="180px">
				<div class="card-title">Mobile Legends</div>
			</div>
		</div>
		<div class="card">
			<div class="card-sizer">
				<img src="img/card/cod.png" alt="Call Of Duty" width="180px" height="180px">
				<div class="card-title">Call Of Duty</div>
			</div>
		</div>
		<div class="card">
			<div class="card-sizer">
				<img src="img/card/pb.jpg" alt="Point Blank" width="180px" height="180px">
				<div class="card-title">Point Blank</div>
			</div>
		</div>
		<div class="card">
			<div class="card-sizer">
				<img src="img/card/minecraft.jpg" alt="Minecraft" width="180px" height="180px">
				<div class="card-title">Minecraft</div>
			</div>
		</div>
		<div class="card">
			<div class="card-sizer">
				<img src="img/card/ytpremium.png" alt="Youtube Premium" width="180px" height="180px">
				<div class="card-title">Youtube Premium</div>
			</div>
		</div>
		<div class="card">
			<div class="card-sizer">
				<img src="img/card/spotify.jpg" alt="Spotify Premium" width="180px" height="180px">
				<div class="card-title">Spotify Premium</div>
			</div>
		</div>
		<div class="card">
			<div class="card-sizer">
				<img src="img/card/discord-nitro.jpg" alt="Discord Nitro" width="180px" height="180px">
				<div class="card-title">Discord Nitro</div>
			</div>
		</div>
		<div class="card">
			<div class="card-sizer">
				<img src="img/card/discord-nitro-classic.jpg" alt="Discord Nitro Classic" width="180px" height="180px">
				<div class="card-title">Discord Nitro</div>
			</div>
		</div>
	</main>
	<!-- End Main/Card -->

	<!-- Start Footer -->
	<footer>
		<div id="bg-wave"></div>
		<div class="footer-container">
			<div class="about">
				<h1>Faris Store</h1>
				<p>faris Store adalah salah satu Start Up Toko Online di indonesia yang berfokus kepada Voucher Game. Dengan berbagai macam metode pembayaran yang tersedia,<br> juga opsi tanpa kartu kredit, registrasi ataupun log-in. dan tentunya Murah, Aman, dan 100% Terpercaya.</p>
			</div>
			<div class="contact">
				<h2>Hubungi Kami!</h2>
				<ul>
					<li>
						<a href="https://wa.me/628813294197?text=Halo,%20Faris%20Store!" target="_blank">
							<i class="i-whatsapp svg-icon"></i> +62 881-3294-197
						</a>
					</li>
					<li>
						<a href="#" target="_blank" class="amail">
							<i class="i-email svg-ico"></i> example@gmail.com
						</a>
					</li>
					<li>
						<a href="#" target="_blank">
							<i class="i-discord svg-icon"></i> Discord Support
						</a>
					</li>
				</ul>
			</div>
			<div class="copyright">
				<hr>
				<p class="copyright-text">Copyright &copy; 2017 All Rights Reserved by 
         <a class="cpy" href="https://wa.me/6285812486745">Hmdan</a>.
            </p>
          </div>
			</div>
		</div>
	</footer>
	<!-- End Footer -->

	<!-- Start Import Script -->
	<script src="js/script.js"></script>
	<script src="js/particles.js"></script>
	<script src="js/svg.js"></script>
	<!-- End Import Script -->
</body>
</html>